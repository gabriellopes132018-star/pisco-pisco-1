# PsicoGestão - Sistema de Gestão para Psicólogos

Sistema completo e profissional de gestão para clínicas de psicologia com agendamento online, prontuário eletrônico, gestão financeira e muito mais.

## Visão Geral do Projeto

Este é um sistema SaaS desenvolvido para psicólogos que precisam de uma solução completa para gerenciar suas clínicas. O sistema inclui:

- **Autenticação Multi-perfil**: Replit Auth com suporte para Google, GitHub, email/senha
- **Dashboard Administrativo**: KPIs em tempo real, consultas do dia, faturamento mensal
- **Agenda Visual**: Calendário semanal interativo com sincronização Google Calendar
- **Gestão de Pacientes**: Cadastro completo, histórico de atendimentos, prontuários
- **Módulo Financeiro**: Controle de receitas/despesas, integração Stripe para pagamentos online
- **Sistema de Tarefas**: Organização com prioridades, status e vinculação com pacientes
- **Prontuário Eletrônico**: Anotações sigilosas em conformidade com LGPD
- **Tema Claro/Escuro**: Interface adaptável com design sofisticado

## Stack Tecnológica

### Frontend
- **React** com TypeScript
- **Wouter** para roteamento
- **TanStack Query** para gerenciamento de estado e cache
- **Shadcn UI** componentes acessíveis e modernos
- **Tailwind CSS** para estilização
- **Framer Motion** para animações suaves
- **date-fns** para manipulação de datas

### Backend
- **Express.js** com TypeScript
- **PostgreSQL** (Neon) para banco de dados
- **Drizzle ORM** para queries type-safe
- **Passport.js** com Replit Auth (OpenID Connect)
- **Google Calendar API** para sincronização de agenda
- **Stripe** para processamento de pagamentos
- **OpenAI API** para funcionalidades de IA

## Estrutura do Banco de Dados

### Tabelas Principais

#### users
- Perfis de usuários (psicólogos, secretários, etc)
- Autenticação via Replit Auth
- Campos: id, email, firstName, lastName, role, specialty, crp, phone

#### patients
- Cadastro completo de pacientes
- Vinculação com psicólogo responsável
- Campos: id, firstName, lastName, email, phone, cpf, birthDate, healthInsurance, notes

#### appointments
- Agendamentos de consultas
- Suporte para presencial e online
- Campos: id, patientId, psychologistId, startTime, endTime, type, status, amount, paymentMethod

#### medicalRecords
- Prontuário eletrônico
- Anotações sigilosas por sessão
- Campos: id, patientId, sessionDate, observations, interventions, evolution

#### payments
- Controle financeiro completo
- Receitas e despesas
- Campos: id, type, amount, category, paymentMethod, status, dueDate

#### tasks
- Gestão de tarefas
- Prioridades e status
- Campos: id, userId, title, description, type, priority, status, dueDate

## Funcionalidades Implementadas (MVP)

### ✅ Autenticação e Usuários
- Login com Google, GitHub, email/senha via Replit Auth
- Controle de permissões por perfil (psicólogo, secretário, paciente)
- Gerenciamento de sessões seguras

### ✅ Dashboard
- KPIs: Consultas hoje, faturamento mensal, taxa de comparecimento, pacientes ativos
- Lista de consultas do dia
- Próximas consultas agendadas
- Estatísticas em tempo real

### ✅ Agenda
- Visualização semanal de consultas
- Criação de novos agendamentos
- Tipos de atendimento: presencial, online, retorno, triagem
- Status: agendado, confirmado, em andamento, finalizado, cancelado
- Navegação entre semanas

### ✅ Gestão de Pacientes
- Cadastro completo com dados pessoais
- Busca por nome ou email
- Listagem com cartões visuais
- Informações de contato e emergência
- Indicador de status (ativo/inativo)

### ✅ Módulo Financeiro
- Dashboard financeiro com receitas, despesas e saldo
- Registro de transações (receitas e despesas)
- Categorização de pagamentos
- Filtros por tipo (receitas/despesas)
- Status de pagamento (pago/pendente/cancelado)
- Valores pendentes a receber

### ✅ Sistema de Tarefas
- Criação de tarefas com título e descrição
- Tipos: administrativa, clínica, comercial, pessoal
- Prioridades: alta, média, baixa
- Status: pendente, em andamento, concluído
- Vinculação com pacientes
- Filtros por status
- Marcação rápida como concluída

### ✅ Configurações
- Perfil do usuário
- Tema claro/escuro
- Configurações de notificações
- Preferências de segurança

### ✅ Design e UX
- Interface moderna e profissional
- Tema claro/escuro totalmente funcional
- Animações suaves e transições
- Design responsivo para todos os dispositivos
- Componentes acessíveis (WCAG 2.1 AA)
- Cores profissionais (azul para confiança)
- Tipografia hierárquica clara

## Próximas Fases (Pós-MVP)

### Fase 2 - Funcionalidades Avançadas
- Videoatendimento integrado (WebRTC)
- Integração WhatsApp API para lembretes
- Sistema de notificações por email
- Prontuário eletrônico completo com editor rico
- Upload de documentos e anexos
- Assinatura digital de consentimentos

### Fase 3 - IA e Automação
- Resumos automáticos de sessões com OpenAI
- Análises preditivas de faturamento
- Sugestões inteligentes de horários
- Alertas proativos

### Fase 4 - Mobile e Integrações
- PWA para acesso mobile
- App nativo (iOS/Android)
- Integração com mais calendários
- Exportação para sistemas contábeis

## Como Executar

1. O sistema já está configurado com todas as dependências
2. As chaves de API necessárias estão configuradas (Stripe, OpenAI, Google Calendar)
3. O banco de dados PostgreSQL está provisionado
4. Execute `npm run dev` para iniciar o servidor

O sistema estará disponível em `https://<seu-repl>.replit.app`

## Variáveis de Ambiente

Todas já configuradas:
- `DATABASE_URL` - PostgreSQL (Neon)
- `SESSION_SECRET` - Sessões seguras
- `OPENAI_API_KEY` - Funcionalidades de IA
- `STRIPE_SECRET_KEY` - Pagamentos backend
- `VITE_STRIPE_PUBLIC_KEY` - Pagamentos frontend
- Google Calendar OAuth configurado via connector

## Integrações

- ✅ **Replit Auth** - Autenticação completa
- ✅ **PostgreSQL Database** - Persistência de dados
- ✅ **Stripe** - Pagamentos online
- ✅ **OpenAI** - Funcionalidades de IA
- ✅ **Google Calendar** - Sincronização de agenda

## Design Guidelines

O sistema segue um design profissional e sofisticado:
- Paleta de cores azul para confiança e profissionalismo
- Tipografia clara com Inter
- Espaçamento consistente (6, 12, 24)
- Cards com hover elevations suaves
- Tema claro/escuro completo
- Componentes Shadcn UI

Para mais detalhes, consulte `design_guidelines.md`

## Arquitetura

- **Frontend**: SPA React com roteamento client-side
- **Backend**: Express API RESTful
- **Banco de Dados**: PostgreSQL com Drizzle ORM
- **Auth**: OpenID Connect via Replit Auth
- **Cache**: TanStack Query para estado do cliente
- **Build**: Vite para desenvolvimento e produção

## Segurança e LGPD

- ✅ Criptografia de dados sensíveis
- ✅ Controle de acesso baseado em perfis
- ✅ Logs de auditoria
- ✅ Sessões seguras com cookies HTTP-only
- ✅ Conformidade LGPD
- ✅ Backup automático

## Contribuição

Este é um sistema proprietário desenvolvido para psicólogos. Entre em contato para mais informações.

## Licença

Todos os direitos reservados © 2025 PsicoGestão
