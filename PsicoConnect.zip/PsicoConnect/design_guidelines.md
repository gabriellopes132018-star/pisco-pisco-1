# Design Guidelines: Sistema de Gestão para Psicólogos

## Design Approach
**System-Based Approach** inspired by modern SaaS productivity tools (Linear, Notion, Asana) with healthcare-appropriate refinements. This is a data-intensive professional application requiring clarity, efficiency, and trust over visual experimentation.

---

## Core Design Principles
1. **Clinical Professionalism**: Inspire confidence and trust appropriate for healthcare
2. **Information Clarity**: Dense data presented with strong visual hierarchy
3. **Efficient Workflows**: Minimize clicks, maximize productivity
4. **Accessibility First**: WCAG 2.1 AA compliance, excellent contrast ratios

---

## Color Palette

### Light Mode
- **Primary Brand**: 210 85% 48% (Professional blue - trust, healthcare)
- **Primary Hover**: 210 85% 42%
- **Background**: 0 0% 100%
- **Surface**: 210 20% 98%
- **Border**: 220 13% 91%
- **Text Primary**: 222 47% 11%
- **Text Secondary**: 215 16% 47%

### Dark Mode
- **Primary Brand**: 210 100% 60%
- **Primary Hover**: 210 100% 55%
- **Background**: 222 47% 11%
- **Surface**: 217 33% 17%
- **Border**: 217 33% 23%
- **Text Primary**: 210 40% 98%
- **Text Secondary**: 215 20% 65%

### Semantic Colors
- **Success**: 142 71% 45% (confirmations, completed sessions)
- **Warning**: 38 92% 50% (pending confirmations, reminders)
- **Error**: 0 84% 60% (cancellations, missed appointments)
- **Info**: 199 89% 48% (notifications, system messages)

---

## Typography

### Font Stack
- **Primary**: 'Inter', -apple-system, system-ui, sans-serif
- **Monospace**: 'JetBrains Mono', 'Fira Code', monospace (for financial data, IDs)

### Type Scale
- **Display (h1)**: text-4xl font-bold tracking-tight (36px)
- **Heading (h2)**: text-2xl font-semibold (24px)
- **Subheading (h3)**: text-lg font-semibold (18px)
- **Body**: text-base (16px)
- **Small**: text-sm (14px)
- **Caption**: text-xs (12px)

### Weights
- Regular (400): Body text, descriptions
- Medium (500): Emphasized text, labels
- Semibold (600): Section headings
- Bold (700): Page titles, important metrics

---

## Layout System

### Spacing Primitives
Core spacing units: **2, 4, 6, 8, 12, 16, 20, 24** (Tailwind units)
- Tight spacing: 2, 4 (compact data tables, form fields)
- Standard: 6, 8 (card padding, section gaps)
- Generous: 12, 16, 20, 24 (page sections, major divisions)

### Grid System
- **Dashboard**: 12-column grid with 6-unit gaps
- **Content Width**: max-w-7xl (1280px) for main content
- **Sidebar**: Fixed 256px (16rem) for navigation
- **Forms**: max-w-2xl (672px) for optimal readability

### Responsive Breakpoints
- Mobile: < 768px (single column, stacked)
- Tablet: 768px - 1024px (2-column where appropriate)
- Desktop: > 1024px (full multi-column layouts)

---

## Component Library

### Navigation
- **Top Bar**: Fixed header (h-16) with logo, search, user menu, notifications
- **Sidebar**: Collapsible navigation with icon + label, active state highlighting
- **Breadcrumbs**: Secondary navigation showing hierarchy

### Cards & Surfaces
- **Elevated Cards**: Shadow-sm with rounded-lg borders
- **Patient Cards**: Avatar + key info, hover state for actions
- **Stats Cards**: Large metric + label + trend indicator
- **Appointment Cards**: Time-based layout with status badges

### Data Display
- **Tables**: Striped rows, sortable columns, sticky headers for long lists
- **Calendar**: Week/month views with color-coded appointment types
- **Charts**: Clean bar/line charts for financial reports using subtle gradients
- **Timeline**: Vertical patient history with session markers

### Forms & Inputs
- **Input Fields**: Rounded-md with focus ring (ring-2 ring-primary)
- **Select Dropdowns**: Native-styled with arrow indicator
- **Date/Time Pickers**: Integrated calendar popups
- **Checkboxes/Radio**: Custom styled matching brand colors
- **Validation**: Inline error messages in error color, success indicators

### Buttons
- **Primary**: Solid background, medium font weight, rounded-md, shadow-sm
- **Secondary**: Outline variant with border
- **Ghost**: Text-only for tertiary actions
- **Sizes**: Small (h-8), Medium (h-10), Large (h-12)

### Overlays
- **Modals**: Centered, max-w-2xl, backdrop blur
- **Slideovers**: Right-side panel for patient details, forms
- **Dropdowns**: Shadow-lg with rounded corners
- **Tooltips**: Small, dark background, white text

### Status Indicators
- **Badges**: Rounded-full for appointment statuses (Agendado, Confirmado, Cancelado)
- **Dots**: Small colored circles for quick status scanning
- **Progress Bars**: For session duration, payment completion

---

## Animation Principles

**Minimal and Purposeful** - This is a professional tool, not a marketing site.

### Approved Animations
- **Page Transitions**: Subtle fade-in (150ms) for route changes
- **Hover States**: Scale hover (scale-105) on cards, brightness on buttons
- **Loading States**: Skeleton screens, spinner for data fetching
- **Drag & Drop**: Smooth transform during calendar rearrangement
- **Notifications**: Slide-in from top-right (300ms ease-out)

### Forbidden
- ❌ Auto-playing videos or carousels
- ❌ Parallax scrolling effects
- ❌ Overly complex page transitions
- ❌ Distracting background animations

---

## Dashboard Design

### Layout Structure
- **Header**: KPI metrics (4 columns) - Total Consultas Hoje, Faturamento Mês, Taxa Comparecimento, Pacientes Ativos
- **Main Content**: 2-column layout
  - **Left (60%)**: Today's agenda calendar view
  - **Right (40%)**: Upcoming appointments list, recent notifications
- **Secondary Row**: Financial chart + patient statistics

### Calendar Component
- **Week View**: 7-column grid with hourly slots
- **Color Coding**: Different appointment types have distinct subtle background colors
- **Drag & Drop**: Visual feedback during move, conflict warnings
- **Quick Actions**: Hover reveals reschedule, cancel, complete buttons

---

## Patient Management

### Patient List
- **Table View**: Sortable columns (Nome, Última Consulta, Próxima Consulta, Status)
- **Search**: Prominent search bar with filters (status, profissional)
- **Actions**: Row-level actions accessible via menu button

### Patient Detail Page
- **Header**: Large avatar, name, key contact info, action buttons (Agendar, Editar)
- **Tabs Navigation**: Histórico, Prontuário, Financeiro, Documentos
- **Timeline**: Chronological session history with expandable notes
- **Stats**: Session count, payment status, attendance rate

---

## Financial Module

### Dashboard View
- **Summary Cards**: Revenue Today, Monthly Total, Pending Payments, Expenses
- **Charts**: Line chart for revenue trends, bar chart for expense categories
- **Recent Transactions**: Table with payment method icons, status badges

### Reports
- **Filters**: Date range picker, professional selector, payment method
- **Export**: Prominent PDF/Excel export buttons
- **Visual Hierarchy**: Large totals, smaller breakdowns

---

## Images
No hero images required - this is a dashboard application. Images used only for:
- **User Avatars**: Circular, 40px standard size, initials fallback
- **Empty States**: Simple illustrations when no data exists (calendar vazio, sem pacientes)
- **Onboarding**: Optional tutorial graphics (small, supportive, not prominent)

---

## Accessibility

- **Contrast Ratios**: Minimum 4.5:1 for all text
- **Keyboard Navigation**: Full tab order, visible focus states
- **Screen Readers**: Proper ARIA labels on all interactive elements
- **Dark Mode**: Consistent implementation across all views including forms and inputs
- **Form Labels**: Always visible, never placeholder-only
- **Error Messages**: Associated with fields via aria-describedby

---

## Key Differentiators

1. **Clinical Aesthetic**: Professional blue palette vs. consumer purples
2. **Dense Information**: Tables and calendars optimized for scanning
3. **Action-Oriented**: Always-visible CTAs for common workflows
4. **Trustworthy**: Consistent, predictable interactions - no surprises
5. **Performance**: Fast transitions, skeleton loading, optimistic UI updates