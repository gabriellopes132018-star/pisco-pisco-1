import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FileText, Lock } from "lucide-react";

export default function Prontuarios() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight" data-testid="heading-records">
          Prontuários Eletrônicos
        </h1>
        <p className="text-muted-foreground mt-1">
          Registros sigilosos e protegidos por LGPD
        </p>
      </div>

      <Card className="border-2 border-dashed">
        <CardContent className="flex flex-col items-center justify-center py-20">
          <div className="h-20 w-20 rounded-full bg-primary/10 flex items-center justify-center mb-6">
            <Lock className="h-10 w-10 text-primary" />
          </div>
          <h3 className="text-2xl font-semibold mb-2">Prontuários Protegidos</h3>
          <p className="text-muted-foreground text-center max-w-md mb-6">
            Seus prontuários eletrônicos estarão disponíveis em breve. Este módulo
            permitirá criar, editar e visualizar registros de sessões de forma segura
            e em conformidade com a LGPD.
          </p>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <FileText className="h-4 w-4" />
            <span>Em desenvolvimento</span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
