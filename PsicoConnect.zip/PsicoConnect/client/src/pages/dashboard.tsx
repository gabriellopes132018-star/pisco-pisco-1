import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Calendar,
  Users,
  DollarSign,
  TrendingUp,
  Clock,
  CheckCircle,
  XCircle,
  AlertCircle,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import type { Appointment, Patient } from "@shared/schema";
import { format, isToday, isFuture, parseISO } from "date-fns";
import { ptBR } from "date-fns/locale";

export default function Dashboard() {
  const { data: appointments = [], isLoading: loadingAppointments } = useQuery<Appointment[]>({
    queryKey: ["/api/appointments"],
  });

  const { data: patients = [], isLoading: loadingPatients } = useQuery<Patient[]>({
    queryKey: ["/api/patients"],
  });

  const { data: stats } = useQuery<{
    todayAppointments: number;
    monthlyRevenue: number;
    attendanceRate: number;
    activePatients: number;
  }>({
    queryKey: ["/api/stats"],
  });

  const todayAppointments = appointments.filter((apt) =>
    apt.startTime ? isToday(new Date(apt.startTime)) : false
  );

  const upcomingAppointments = appointments
    .filter((apt) => apt.startTime && isFuture(new Date(apt.startTime)))
    .sort((a, b) => new Date(a.startTime!).getTime() - new Date(b.startTime!).getTime())
    .slice(0, 5);

  const getStatusColor = (status: string) => {
    switch (status) {
      case "agendado":
        return "bg-blue-500/10 text-blue-700 dark:text-blue-400";
      case "confirmado":
        return "bg-green-500/10 text-green-700 dark:text-green-400";
      case "em_andamento":
        return "bg-yellow-500/10 text-yellow-700 dark:text-yellow-400";
      case "finalizado":
        return "bg-gray-500/10 text-gray-700 dark:text-gray-400";
      case "cancelado":
        return "bg-red-500/10 text-red-700 dark:text-red-400";
      default:
        return "bg-gray-500/10 text-gray-700 dark:text-gray-400";
    }
  };

  const getStatusLabel = (status: string) => {
    const labels: Record<string, string> = {
      agendado: "Agendado",
      confirmado: "Confirmado",
      em_andamento: "Em Andamento",
      finalizado: "Finalizado",
      cancelado: "Cancelado",
      falta: "Falta",
    };
    return labels[status] || status;
  };

  const statCards = [
    {
      title: "Consultas Hoje",
      value: stats?.todayAppointments ?? todayAppointments.length,
      icon: Calendar,
      color: "text-blue-600 dark:text-blue-400",
      bgColor: "bg-blue-500/10",
      testId: "stat-today-appointments",
    },
    {
      title: "Faturamento Mensal",
      value: `R$ ${(stats?.monthlyRevenue ?? 0).toLocaleString("pt-BR", {
        minimumFractionDigits: 2,
      })}`,
      icon: DollarSign,
      color: "text-green-600 dark:text-green-400",
      bgColor: "bg-green-500/10",
      testId: "stat-monthly-revenue",
    },
    {
      title: "Taxa de Comparecimento",
      value: `${stats?.attendanceRate ?? 0}%`,
      icon: TrendingUp,
      color: "text-purple-600 dark:text-purple-400",
      bgColor: "bg-purple-500/10",
      testId: "stat-attendance-rate",
    },
    {
      title: "Pacientes Ativos",
      value: stats?.activePatients ?? patients.filter((p) => p.isActive).length,
      icon: Users,
      color: "text-orange-600 dark:text-orange-400",
      bgColor: "bg-orange-500/10",
      testId: "stat-active-patients",
    },
  ];

  if (loadingAppointments || loadingPatients) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight" data-testid="heading-dashboard">
          Dashboard
        </h1>
        <p className="text-muted-foreground mt-1">
          Visão geral da sua clínica
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        {statCards.map((card) => (
          <Card key={card.title} className="hover-elevate transition-all duration-300">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                {card.title}
              </CardTitle>
              <div className={`p-2 rounded-lg ${card.bgColor}`}>
                <card.icon className={`h-4 w-4 ${card.color}`} />
              </div>
            </CardHeader>
            <CardContent>
              <div
                className="text-2xl font-bold"
                data-testid={card.testId}
              >
                {card.value}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0">
            <div>
              <CardTitle>Consultas de Hoje</CardTitle>
              <p className="text-sm text-muted-foreground mt-1">
                {todayAppointments.length} consulta(s) agendada(s)
              </p>
            </div>
            <Button asChild variant="outline" size="sm" data-testid="button-view-agenda">
              <Link href="/agenda">
                <Calendar className="h-4 w-4 mr-2" />
                Ver Agenda
              </Link>
            </Button>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {todayAppointments.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Calendar className="h-12 w-12 mx-auto mb-3 opacity-20" />
                  <p>Nenhuma consulta agendada para hoje</p>
                </div>
              ) : (
                todayAppointments.map((appointment) => (
                  <div
                    key={appointment.id}
                    className="flex items-center gap-4 p-4 rounded-lg hover-elevate"
                    data-testid={`appointment-today-${appointment.id}`}
                  >
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <Clock className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm font-medium">
                          {appointment.startTime &&
                            format(
                              new Date(appointment.startTime),
                              "HH:mm",
                              { locale: ptBR }
                            )}
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">
                        Paciente ID: {appointment.patientId}
                      </p>
                    </div>
                    <Badge className={getStatusColor(appointment.status)}>
                      {getStatusLabel(appointment.status)}
                    </Badge>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0">
            <div>
              <CardTitle>Próximas Consultas</CardTitle>
              <p className="text-sm text-muted-foreground mt-1">
                Agenda dos próximos dias
              </p>
            </div>
            <Button asChild variant="outline" size="sm" data-testid="button-new-appointment">
              <Link href="/agenda">Novo Agendamento</Link>
            </Button>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {upcomingAppointments.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <CheckCircle className="h-12 w-12 mx-auto mb-3 opacity-20" />
                  <p>Nenhuma consulta futura agendada</p>
                </div>
              ) : (
                upcomingAppointments.map((appointment) => (
                  <div
                    key={appointment.id}
                    className="flex items-center justify-between p-4 rounded-lg hover-elevate"
                    data-testid={`appointment-upcoming-${appointment.id}`}
                  >
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium">
                        {appointment.startTime &&
                          format(
                            new Date(appointment.startTime),
                            "dd 'de' MMMM 'às' HH:mm",
                            { locale: ptBR }
                          )}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {appointment.type === "presencial"
                          ? "Presencial"
                          : "Online"}
                      </p>
                    </div>
                    <Badge className={getStatusColor(appointment.status)} variant="outline">
                      {getStatusLabel(appointment.status)}
                    </Badge>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
