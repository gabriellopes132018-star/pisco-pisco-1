import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Plus,
  TrendingUp,
  TrendingDown,
  DollarSign,
  Download,
  Filter,
  CreditCard,
  Wallet,
  ArrowUpCircle,
  ArrowDownCircle,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";
import type { Payment } from "@shared/schema";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function Financeiro() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [transactionType, setTransactionType] = useState<"receita" | "despesa">("receita");
  const { toast } = useToast();
  const { user } = useAuth();

  const { data: payments = [], isLoading } = useQuery<Payment[]>({
    queryKey: ["/api/payments"],
  });

  const createPaymentMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/payments", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/payments"] });
      toast({
        title: "Sucesso",
        description: "Transação registrada com sucesso!",
      });
      setIsDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Erro",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const paymentData = {
      psychologistId: user?.id,
      type: transactionType,
      category: formData.get("category"),
      description: formData.get("description"),
      amount: formData.get("amount"),
      paymentMethod: formData.get("paymentMethod"),
      status: formData.get("status") || "pendente",
      dueDate: formData.get("dueDate")
        ? new Date(formData.get("dueDate") as string).toISOString()
        : null,
    };

    createPaymentMutation.mutate(paymentData);
  };

  const revenues = payments.filter((p) => p.type === "receita");
  const expenses = payments.filter((p) => p.type === "despesa");

  const totalRevenue = revenues.reduce((sum, p) => sum + parseFloat(p.amount || "0"), 0);
  const totalExpenses = expenses.reduce((sum, p) => sum + parseFloat(p.amount || "0"), 0);
  const balance = totalRevenue - totalExpenses;

  const paidRevenue = revenues
    .filter((p) => p.status === "pago")
    .reduce((sum, p) => sum + parseFloat(p.amount || "0"), 0);
  const pendingRevenue = revenues
    .filter((p) => p.status === "pendente")
    .reduce((sum, p) => sum + parseFloat(p.amount || "0"), 0);

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pago":
        return "bg-green-500/10 text-green-700 dark:text-green-400";
      case "pendente":
        return "bg-yellow-500/10 text-yellow-700 dark:text-yellow-400";
      case "cancelado":
        return "bg-red-500/10 text-red-700 dark:text-red-400";
      default:
        return "bg-gray-500/10 text-gray-700 dark:text-gray-400";
    }
  };

  const getStatusLabel = (status: string) => {
    const labels: Record<string, string> = {
      pago: "Pago",
      pendente: "Pendente",
      cancelado: "Cancelado",
    };
    return labels[status] || status;
  };

  const getPaymentMethodIcon = (method: string) => {
    switch (method) {
      case "cartao":
        return <CreditCard className="h-4 w-4" />;
      case "pix":
      case "dinheiro":
        return <Wallet className="h-4 w-4" />;
      default:
        return <DollarSign className="h-4 w-4" />;
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight" data-testid="heading-financial">
            Financeiro
          </h1>
          <p className="text-muted-foreground mt-1">
            Controle completo de receitas e despesas
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" data-testid="button-export">
            <Download className="h-4 w-4 mr-2" />
            Exportar
          </Button>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button data-testid="button-new-transaction">
                <Plus className="h-4 w-4 mr-2" />
                Nova Transação
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[500px]">
              <form onSubmit={handleSubmit}>
                <DialogHeader>
                  <DialogTitle>Registrar Transação</DialogTitle>
                  <DialogDescription>
                    Adicione uma nova receita ou despesa
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="space-y-2">
                    <Label>Tipo de Transação</Label>
                    <Tabs
                      value={transactionType}
                      onValueChange={(v) => setTransactionType(v as "receita" | "despesa")}
                    >
                      <TabsList className="grid w-full grid-cols-2">
                        <TabsTrigger value="receita" data-testid="tab-revenue">
                          Receita
                        </TabsTrigger>
                        <TabsTrigger value="despesa" data-testid="tab-expense">
                          Despesa
                        </TabsTrigger>
                      </TabsList>
                    </Tabs>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="description">Descrição *</Label>
                    <Input
                      id="description"
                      name="description"
                      placeholder="Ex: Consulta com paciente João"
                      required
                      data-testid="input-description"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="amount">Valor (R$) *</Label>
                      <Input
                        id="amount"
                        name="amount"
                        type="number"
                        step="0.01"
                        placeholder="0.00"
                        required
                        data-testid="input-amount"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="category">Categoria</Label>
                      <Select name="category">
                        <SelectTrigger data-testid="select-category">
                          <SelectValue placeholder="Selecione" />
                        </SelectTrigger>
                        <SelectContent>
                          {transactionType === "receita" ? (
                            <>
                              <SelectItem value="consulta">Consulta</SelectItem>
                              <SelectItem value="particular">Particular</SelectItem>
                              <SelectItem value="convenio">Convênio</SelectItem>
                            </>
                          ) : (
                            <>
                              <SelectItem value="aluguel">Aluguel</SelectItem>
                              <SelectItem value="salario">Salário</SelectItem>
                              <SelectItem value="material">Material</SelectItem>
                              <SelectItem value="outros">Outros</SelectItem>
                            </>
                          )}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="paymentMethod">Forma de Pagamento</Label>
                      <Select name="paymentMethod">
                        <SelectTrigger data-testid="select-payment-method">
                          <SelectValue placeholder="Selecione" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="dinheiro">Dinheiro</SelectItem>
                          <SelectItem value="pix">PIX</SelectItem>
                          <SelectItem value="cartao">Cartão</SelectItem>
                          <SelectItem value="transferencia">Transferência</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="status">Status</Label>
                      <Select name="status" defaultValue="pendente">
                        <SelectTrigger data-testid="select-status">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="pago">Pago</SelectItem>
                          <SelectItem value="pendente">Pendente</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="dueDate">Data de Vencimento</Label>
                    <Input
                      id="dueDate"
                      name="dueDate"
                      type="date"
                      data-testid="input-due-date"
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                    Cancelar
                  </Button>
                  <Button type="submit" disabled={createPaymentMutation.isPending} data-testid="button-save-transaction">
                    {createPaymentMutation.isPending ? "Salvando..." : "Registrar"}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-4">
        <Card className="hover-elevate transition-all duration-300">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Receitas Totais</CardTitle>
            <div className="p-2 rounded-lg bg-green-500/10">
              <ArrowUpCircle className="h-4 w-4 text-green-600 dark:text-green-400" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600 dark:text-green-400" data-testid="stat-total-revenue">
              R$ {totalRevenue.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {revenues.length} transação(ões)
            </p>
          </CardContent>
        </Card>

        <Card className="hover-elevate transition-all duration-300">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Despesas Totais</CardTitle>
            <div className="p-2 rounded-lg bg-red-500/10">
              <ArrowDownCircle className="h-4 w-4 text-red-600 dark:text-red-400" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600 dark:text-red-400" data-testid="stat-total-expenses">
              R$ {totalExpenses.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {expenses.length} transação(ões)
            </p>
          </CardContent>
        </Card>

        <Card className="hover-elevate transition-all duration-300">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Saldo</CardTitle>
            <div className={`p-2 rounded-lg ${balance >= 0 ? "bg-blue-500/10" : "bg-orange-500/10"}`}>
              <DollarSign className={`h-4 w-4 ${balance >= 0 ? "text-blue-600 dark:text-blue-400" : "text-orange-600 dark:text-orange-400"}`} />
            </div>
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${balance >= 0 ? "text-blue-600 dark:text-blue-400" : "text-orange-600 dark:text-orange-400"}`} data-testid="stat-balance">
              R$ {balance.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Receitas - Despesas
            </p>
          </CardContent>
        </Card>

        <Card className="hover-elevate transition-all duration-300">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">A Receber</CardTitle>
            <div className="p-2 rounded-lg bg-yellow-500/10">
              <TrendingUp className="h-4 w-4 text-yellow-600 dark:text-yellow-400" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600 dark:text-yellow-400" data-testid="stat-pending">
              R$ {pendingRevenue.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Receitas pendentes
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="all" className="space-y-4">
        <TabsList>
          <TabsTrigger value="all" data-testid="tab-all">Todas</TabsTrigger>
          <TabsTrigger value="receitas" data-testid="tab-revenues">Receitas</TabsTrigger>
          <TabsTrigger value="despesas" data-testid="tab-expenses">Despesas</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Todas as Transações</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {payments.length === 0 ? (
                  <div className="text-center py-12">
                    <DollarSign className="h-16 w-16 mx-auto mb-4 text-muted-foreground opacity-20" />
                    <p className="text-lg font-medium">Nenhuma transação registrada</p>
                    <p className="text-muted-foreground mt-1">
                      Comece adicionando suas primeiras transações
                    </p>
                  </div>
                ) : (
                  payments.map((payment) => (
                    <div
                      key={payment.id}
                      className="flex items-center justify-between p-4 rounded-lg border hover-elevate"
                      data-testid={`transaction-${payment.id}`}
                    >
                      <div className="flex items-center gap-4 flex-1">
                        <div className={`p-3 rounded-lg ${
                          payment.type === "receita"
                            ? "bg-green-500/10"
                            : "bg-red-500/10"
                        }`}>
                          {payment.type === "receita" ? (
                            <ArrowUpCircle className="h-5 w-5 text-green-600 dark:text-green-400" />
                          ) : (
                            <ArrowDownCircle className="h-5 w-5 text-red-600 dark:text-red-400" />
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium truncate">{payment.description}</p>
                          <div className="flex items-center gap-3 mt-1">
                            <span className="text-sm text-muted-foreground">
                              {payment.category}
                            </span>
                            {payment.paymentMethod && (
                              <div className="flex items-center gap-1 text-sm text-muted-foreground">
                                {getPaymentMethodIcon(payment.paymentMethod)}
                                <span>{payment.paymentMethod}</span>
                              </div>
                            )}
                            {payment.dueDate && (
                              <span className="text-sm text-muted-foreground">
                                {format(new Date(payment.dueDate), "dd/MM/yyyy")}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <Badge className={getStatusColor(payment.status)}>
                          {getStatusLabel(payment.status)}
                        </Badge>
                        <div className={`text-lg font-semibold min-w-[120px] text-right ${
                          payment.type === "receita"
                            ? "text-green-600 dark:text-green-400"
                            : "text-red-600 dark:text-red-400"
                        }`}>
                          {payment.type === "receita" ? "+" : "-"} R${" "}
                          {parseFloat(payment.amount || "0").toLocaleString("pt-BR", {
                            minimumFractionDigits: 2,
                          })}
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="receitas" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Receitas</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {revenues.map((payment) => (
                  <div
                    key={payment.id}
                    className="flex items-center justify-between p-4 rounded-lg border hover-elevate"
                  >
                    <div className="flex items-center gap-4 flex-1">
                      <div className="p-3 rounded-lg bg-green-500/10">
                        <ArrowUpCircle className="h-5 w-5 text-green-600 dark:text-green-400" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium truncate">{payment.description}</p>
                        <p className="text-sm text-muted-foreground">
                          {payment.category}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <Badge className={getStatusColor(payment.status)}>
                        {getStatusLabel(payment.status)}
                      </Badge>
                      <div className="text-lg font-semibold text-green-600 dark:text-green-400 min-w-[120px] text-right">
                        + R${" "}
                        {parseFloat(payment.amount || "0").toLocaleString("pt-BR", {
                          minimumFractionDigits: 2,
                        })}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="despesas" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Despesas</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {expenses.map((payment) => (
                  <div
                    key={payment.id}
                    className="flex items-center justify-between p-4 rounded-lg border hover-elevate"
                  >
                    <div className="flex items-center gap-4 flex-1">
                      <div className="p-3 rounded-lg bg-red-500/10">
                        <ArrowDownCircle className="h-5 w-5 text-red-600 dark:text-red-400" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium truncate">{payment.description}</p>
                        <p className="text-sm text-muted-foreground">
                          {payment.category}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <Badge className={getStatusColor(payment.status)}>
                        {getStatusLabel(payment.status)}
                      </Badge>
                      <div className="text-lg font-semibold text-red-600 dark:text-red-400 min-w-[120px] text-right">
                        - R${" "}
                        {parseFloat(payment.amount || "0").toLocaleString("pt-BR", {
                          minimumFractionDigits: 2,
                        })}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
