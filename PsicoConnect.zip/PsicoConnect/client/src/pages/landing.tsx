import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Calendar,
  Users,
  DollarSign,
  FileText,
  BarChart3,
  Shield,
  Clock,
  CheckCircle,
} from "lucide-react";

export default function Landing() {
  const features = [
    {
      icon: Calendar,
      title: "Agenda Inteligente",
      description:
        "Calendário visual com sincronização Google Calendar e lembretes automáticos",
    },
    {
      icon: Users,
      title: "Gestão de Pacientes",
      description:
        "Cadastro completo, histórico de atendimentos e linha do tempo de evolução",
    },
    {
      icon: FileText,
      title: "Prontuário Eletrônico",
      description:
        "Anotações sigilosas, campos customizáveis e total conformidade LGPD",
    },
    {
      icon: DollarSign,
      title: "Controle Financeiro",
      description:
        "Pagamentos online, emissão de recibos e relatórios financeiros detalhados",
    },
    {
      icon: BarChart3,
      title: "Relatórios Avançados",
      description:
        "KPIs em tempo real, gráficos interativos e análises de produtividade",
    },
    {
      icon: Shield,
      title: "Segurança LGPD",
      description:
        "Criptografia de dados, controle de acesso e logs de auditoria",
    },
  ];

  const benefits = [
    "Reduza tempo administrativo em até 70%",
    "Sincronize com Google Calendar automaticamente",
    "Receba pagamentos online via Stripe",
    "Acesse de qualquer dispositivo",
    "Dados 100% seguros e criptografados",
    "Suporte em português",
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-card to-background">
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="h-10 w-10 rounded-lg bg-primary flex items-center justify-center">
              <FileText className="h-6 w-6 text-primary-foreground" />
            </div>
            <h1 className="text-xl font-bold">PsicoGestão</h1>
          </div>
          <Button asChild data-testid="button-login">
            <a href="/api/login">Entrar</a>
          </Button>
        </div>
      </header>

      <main>
        <section className="container mx-auto px-4 py-20 md:py-32">
          <div className="max-w-4xl mx-auto text-center space-y-8">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium">
              <CheckCircle className="h-4 w-4" />
              Sistema Profissional para Psicólogos
            </div>

            <h2 className="text-4xl md:text-6xl font-bold tracking-tight">
              Gerencie sua clínica com{" "}
              <span className="text-primary">eficiência</span> e{" "}
              <span className="text-primary">segurança</span>
            </h2>

            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Sistema completo de gestão para psicólogos com agenda, prontuário
              eletrônico, gestão financeira e muito mais. Tudo em um só lugar.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
              <Button size="lg" asChild data-testid="button-start">
                <a href="/api/login" className="text-base">
                  Começar Gratuitamente
                </a>
              </Button>
              <Button size="lg" variant="outline" data-testid="button-demo">
                <Clock className="h-5 w-5 mr-2" />
                Ver Demonstração
              </Button>
            </div>
          </div>
        </section>

        <section className="container mx-auto px-4 py-20">
          <h3 className="text-3xl font-bold text-center mb-12">
            Tudo que você precisa em um só sistema
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
            {features.map((feature, index) => (
              <Card key={index} className="hover-elevate transition-all duration-300">
                <CardContent className="p-6 space-y-3">
                  <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
                    <feature.icon className="h-6 w-6 text-primary" />
                  </div>
                  <h4 className="text-lg font-semibold">{feature.title}</h4>
                  <p className="text-muted-foreground text-sm">
                    {feature.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        <section className="container mx-auto px-4 py-20">
          <div className="max-w-4xl mx-auto">
            <Card className="bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20">
              <CardContent className="p-12 space-y-8">
                <h3 className="text-3xl font-bold text-center">
                  Por que escolher o PsicoGestão?
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {benefits.map((benefit, index) => (
                    <div key={index} className="flex items-start gap-3">
                      <CheckCircle className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                      <span className="text-sm">{benefit}</span>
                    </div>
                  ))}
                </div>
                <div className="flex justify-center pt-4">
                  <Button size="lg" asChild data-testid="button-cta">
                    <a href="/api/login">Comece Agora - É Grátis</a>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>
      </main>

      <footer className="border-t py-12 mt-20">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>&copy; 2025 PsicoGestão. Todos os direitos reservados.</p>
          <p className="mt-2">Sistema em conformidade com LGPD</p>
        </div>
      </footer>
    </div>
  );
}
